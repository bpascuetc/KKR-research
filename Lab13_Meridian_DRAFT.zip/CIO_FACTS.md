# Meridian Foundation Reserve — governing case facts

Source: user-supplied screenshot, “Week 8 Common CIO Case — Meridian Foundation Reserve,” received October 16, 2026. The image is preserved as CIO_CASE.png. This is a faithful indexed transcription of the decision facts, not an outside source or an expanded client profile.

- **F0 — scope:** Fictional, course-authored common case for Lab 13. Do not add unstated facts. It is not evidence about the student's Project 2.
- **F1 — user/action/date:** As of October 15, 2026, the CIO asks an analyst to propose a policy allocation and validation plan for a $100 million reserve. The committee decides whether to authorize analysis and a small pilot, not whether to execute trades today.
- **F2 — timing:** Seven-year policy horizon; quarterly review; annual rebalancing.
- **F3 — objective:** CPI + 4% net of estimated costs over rolling five-year periods; an objective, not a guaranteed outcome.
- **F4 — distributions:** $750,000 at the end of each calendar quarter. At least twelve months of scheduled distributions must remain in cash or daily-liquid government securities.
- **F5 — benchmark:** 60% broad global equities / 40% U.S. investment-grade bonds.
- **F6 — implementation:** Long-only; no borrowing, short sales, or derivatives.
- **F7 — concentration/turnover:** A single issuer may not exceed 8%. Annual turnover should not exceed 25% unless the committee approves a documented exception.
- **F8 — liquidity:** At least 90% redeemable within five business days under ordinary market conditions.
- **F9 — loss statement:** “The reserve cannot have a calendar-year loss greater than 10%.” No enforcement rule, probability, or response to an unavoidable breach is supplied.
- **F10 — absent preferences:** No sector, climate, social, tax, active-management, or home-bias preference is provided.
- **F11 — missing tradeoff:** The committee has not defined whether the pilot should optimize expected return, tracking error, drawdown risk, probability of meeting distributions, or another measurable tradeoff.

## Process requirements from the same screenshot

Before AI, classify each statement as an objective, hard constraint, preference, aspiration, or unverifiable promise; draft the mandate, constraints, baseline, validation and minimum escalation questions. That unaided step is not evidenced in this conversation and cannot be recreated retrospectively.

Give each accessible course-supported system the facts and this exact request:

> Propose two materially different operational interpretations of the Meridian Foundation mandate. For each interpretation, list the objective, hard constraints, assumptions you had to invent, validation tests, and the one CIO question that must be answered before optimization. Do not choose securities or produce an allocation.

Preserve both systems' outputs separately. Mark each material claim supported, unsupported, or requires clarification and cite its governing fact. System agreement does not resolve missing CIO preferences. If an interface is unavailable, use the published COURSE-RUN PROBE route with the exact common prompt and the student's prediction. Those fallback instructions have not yet been supplied.

Do not merge facts from the separate optional “Open-Ended Challenge — Mandate Collision.”

## Disclaimer

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
