# Lab 13 — actual two-system comparison

## Provenance and boundary

System A: OpenAI Codex; response preserved in [SYSTEM_A_CODEX.md](SYSTEM_A_CODEX.md). System B: Google Antigravity, identified by Bernat; response pasted by him in this conversation and preserved separately in [SYSTEM_B_RAW.md](SYSTEM_B_RAW.md). Received October 16, 2026 in the active session. The raw file preserves the supplied response without editorial commentary or an appended disclaimer because it is third-party source material. Antigravity's underlying model is not supplied.

This is the newly supplied response following the prompt handoff, not a reconstruction of the earlier lost response. The exact request supplied for the rerun is in [SECOND_SYSTEM_REQUEST.md](SECOND_SYSTEM_REQUEST.md); the raw reply does not itself prove the precise submitted prompt. The prior lost-output report remains historical, superseded for current comparison evidence by this actual pasted response. Neither system selected securities or optimized an allocation.

Facts F0–F11 refer to [CIO_FACTS.md](CIO_FACTS.md). Tags assess support as **case facts**, not whether a proposal could be useful. “Requires clarification” means a possible interpretation or method needs approval; “unsupported” means an asserted preference, numerical rule or inference cannot be admitted as supplied authority.

## Antigravity claim dispositions

| Material claim | Evidence classification | My disposition |
|---|---|---|
| Both interpretations: $3m minimum reserve | **Supported — F1/F4:** four $750k payments; initially 3% of $100m. | Accept; maintain the next-twelve-month dollar floor after payouts, not just at inception. |
| Both: long-only, no borrowing/shorts/derivatives | **Supported — F6.** | Accept; verify instrument eligibility. |
| Both: single issuer ≤8% | **Supported — F7.** | Accept limit; defer issuer/fund/look-through/government scope. No exemption inferred. |
| Both: turnover ≤25% absent documented exception | **Supported — F7.** | Accept; agree measurement convention before implementation. |
| Both: ≥90% ordinary five-business-day liquidity | **Supported — F8.** | Accept; this does not guarantee distressed liquidity. |
| I1: benchmark is global-equity/U.S.-IG 60/40 | **Supported — F5.** | Accept reference; it is not mandatory portfolio weights. |
| I1: maximize expected return relative to benchmark | **Requires clarification — F11 explicitly leaves the optimized tradeoff undefined.** | Defer pending CIO selection; a benchmark does not imply an alpha objective. |
| I1: require achievement of CPI+4 as an optimization constraint | **Unsupported as a supplied hard rule — F3 says objective, not guaranteed outcome.** | Reject that conversion of aspiration to hard requirement; report attainment and shortfalls. |
| I1: bound tracking error | **Unsupported as a supplied preference — F11.** | Reject as a default; no tracking-error ceiling is provided. |
| I1: loss is a statistical VaR/CVaR budget | **Requires clarification — F9 supplies no probability/enforcement rule.** | Defer. VaR and CVaR are distinct measures, not interchangeable; select neither without approval. |
| I1: 95% or 99% confidence | **Unsupported numerical mandate — F9.** | Reject as client authority. Antigravity labels these invented examples; do not adopt them. A 95%/99% VaR threshold would correspond to a modeled 5%/1% exceedance budget, not a guarantee. |
| I1: “>10% drawdown” substitutes for calendar-year loss | **Unsupported equivalence — F9 specifies calendar-year loss.** | Correct: calendar-year net return and peak-to-trough drawdown are separate measures. |
| I1: benchmark classes define the complete universe | **Requires clarification — F4/F5/F6 do not give an exhaustive universe.** | Retain only as an initial research proposal, including the required reserve. |
| I1: policy drift bands around 60/40 | **Unsupported as a supplied rule — F5/F11.** | Reject invented bands; the case provides no bands. |
| I1: payouts funded by income or rebalance sales | **Requires clarification — F2/F4 specify annual rebalance but quarterly payouts.** | Defer; define settled payment cash and reserve replenishment even when income is insufficient. Do not assume quarterly strategic rebalance. |
| I1: historical crisis tests | **Requires clarification as a proposed method — F3/F9.** | Retain as development/stress design; distinguish calendar-year returns, rolling 12-month returns and drawdowns. No inspected result or future guarantee follows. |
| I1: 1,000+ Monte Carlo paths | **Requires clarification as a proposed method — F3/F9/F11.** | Defer model/distribution and precision choices. Path count alone does not establish reliable tail probabilities; holdout and model-error checks remain needed. |
| I1: ordinary and distressed liquidity tests with payouts | **Requires clarification as a proposed method — F4/F8.** | Retain ordinary compliance plus separate hypothetical stress diagnostics. Do not relabel the ordinary rule as a crisis guarantee. |
| I1: ask whether loss is statistical or absolute | **Supported need for clarification — F9/F11.** | Retain escalation; add selected objective, loss measurement and breach response. |
| I2: capital preservation overrides return target | **Requires clarification — F3/F9/F11 do not establish that hierarchy.** | Retain loss-first only as a discussion proposal; no approval implied. |
| I2: minimize probability and magnitude of “calendar-year drawdown” | **Requires clarification of objective — F11; unsupported metric equivalence — F9.** | Defer probability/magnitude tradeoff; use calendar-year return and drawdown separately. |
| I2: benchmark is a reference rather than mandatory weights | **Supported — F5 calls it the policy benchmark.** | Accept distinction. This does not approve unlimited deviation or every asset. |
| I2: heavy deviations into lower-volatility assets | **Requires clarification — F4/F5/F6/F11.** | Defer universe/priority approval; low volatility is not guaranteed loss protection. |
| I2: de-risk at -6% to -8% | **Unsupported numerical rule — F9 supplies no response rule; F2/F7 govern rebalancing/turnover.** | Reject as default. Any such protocol needs approval, gap-risk analysis and turnover/cost treatment; it cannot guarantee the -10% limit. |
| I2: historical tests “verify” no future breach | **Unsupported if treated as prospective assurance — F9.** | Historical tests only establish what happened in those samples; never verify a future guarantee. |
| I2: return-shortfall and reserve-depletion tests | **Requires clarification as proposed methods — F3/F4.** | Retain; include costs, reserve replenishment, holdout and funding failure criteria. Estimated probabilities need an explicit model. |
| I2: ask priority if return/loss goals conflict | **Supported need for clarification — F3/F9/F11.** | Retain escalation; do not equate optimizer infeasibility with proof that no real-world solution exists. Results are conditional on model and universe. |

## Comparison and my decision

Codex A (loss-first) most closely corresponds to Antigravity I2; Codex B (target-probability) only partly corresponds to Antigravity I1. Antigravity I1 adds benchmark-relative return and tracking error, which are different objectives from maximizing target-achievement probability. Both systems recognize a $3m reserve and the same stated operational limits. Neither agreement nor a plausible interpretation authorizes a missing client preference.

I **retain a corrected loss-first interpretation for discussion**, with calendar-year net investment return as the loss metric and drawdown as a separate diagnostic. I **defer Antigravity's benchmark-tracker interpretation** because its alpha objective, tracking-error limit and probability budget need CIO approval. I **reject invented numerical limits** (95%/99% confidence as mandate parameters, -6%/-8% de-risk triggers and unstated allocation bands), while acknowledging Antigravity explicitly labeled several as invented assumptions.

The Antigravity response does not specify an untouched chronological holdout, point-in-time data cutoff, detailed cost stress or precommitted pass/fail decision rule. It also does not restate quarterly review/annual rebalance consistently in its hard constraints. I retain those supplied timing rules and fill the validation-design gaps explicitly in [Lab13_Meridian.md](Lab13_Meridian.md), rather than attributing them to Antigravity.

**Escalation:** “Does the 10% statement mean a scenario limit, a probability budget or a guaranteed outcome, measured as calendar-year net investment return excluding distributions? Which objective takes priority when CPI+4 conflicts with loss protection, and what response do you authorize after a breach?” This is the documented question for the CIO, not a claim that a CIO has replied. Written approval of a probabilistic loss budget and target-achievement priority would reverse the proposed loss-first formulation. Until clarification, no optimization or pilot implementation.

## Disclaimer

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
