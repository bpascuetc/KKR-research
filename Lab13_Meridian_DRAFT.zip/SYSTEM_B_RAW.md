### Interpretation 1: Target-Return Benchmark Tracker

This interpretation treats the mandate primarily as a relative-risk, total-return portfolio centered on the stated policy benchmark (60/40), seeking to deliver CPI + 4% over rolling five-year horizons while handling the 10% calendar-year loss threshold as a tail-risk budget rather than an absolute impossibility.

* **Objective:** Maximize expected net return relative to the 60/40 policy benchmark, subject to achieving CPI + 4% over five-year rolling periods and bounding benchmark tracking error.
* **Hard Constraints:**
* Minimum $3.0 million (four quarters $\times$ $750,000) held in cash or daily-liquid government securities.
* Long-only holdings only; 0% leverage/borrowing, 0% short sales, 0% derivatives.
* Single-issuer exposure capped at $\le 8\%$.
* Annual portfolio turnover $\le 25\%$ without an approved committee exception.
* $\ge 90\%$ of the aggregate portfolio redeemable within five business days under ordinary conditions.


* **Assumptions Invented:**
* The CIO’s statement on losses is interpreted statistically as a Value-at-Risk (VaR) or Conditional Value-at-Risk (CVaR) tolerance (e.g., maximum 1-year loss $\le 10\%$ at a 95% or 99% confidence level), acknowledging that a 60/40 long-only asset allocation without derivatives cannot guarantee zero tail probability of a $>10\%$ drawdown.
* "Broad global equities" and "U.S. investment-grade bonds" serve as the direct asset class universe, with asset weightings allowed to drift within defined policy bands around 60/40.
* Scheduled quarterly distributions of $750,000 are funded directly from income yield or periodic rebalancing cash flows rather than an expanding cash buffer.


* **Validation Tests:**
* **Historical 60/40 Stress Testing:** Evaluate rolling 1-year calendar returns and maximum drawdowns across historical crises (e.g., 2008, 2022) to quantify the historical frequency and magnitude of calendar-year losses exceeding 10%.
* **Monte Carlo Terminal & Horizon Simulations:** Test 1,000+ paths over 5-year and 7-year windows to evaluate the probability of achieving CPI + 4% net of estimated costs alongside the probability of breaching the 1-year 10% loss threshold.
* **Liquidity & Distribution Stress Test:** Simulate five-day redemption liquidity profiles during standard and distressed liquidity regimes while subtracting scheduled quarterly outflows.


* **CIO Question to Answer Before Optimization:**
* *"Should the 10% maximum calendar-year loss be defined as a statistical confidence threshold (e.g., a 95% or 99% 1-year VaR constraint), or is it an absolute, non-negotiable ceiling that overrides the 60/40 benchmark and CPI + 4% return target?"*



---

### Interpretation 2: Absolute Downside Capital-Preservation Mandate

This interpretation treats the CIO’s statement on losses as the primary non-negotiable directive. It prioritizes capital preservation and the $750,000 quarterly payout schedule over tracking the 60/40 benchmark or reaching CPI + 4%, structuring the portfolio with an emphasis on low-volatility and capital-preservation assets.

* **Objective:** Minimize the probability and magnitude of any calendar-year drawdown approaching 10%, while secondarily maximizing real return toward CPI + 4% and funding scheduled distributions.
* **Hard Constraints:**
* Minimum $3.0 million (four quarters $\times$ $750,000) held in cash or daily-liquid government securities.
* Long-only holdings only; 0% leverage/borrowing, 0% short sales, 0% derivatives.
* Single-issuer exposure capped at $\le 8\%$.
* Annual portfolio turnover $\le 25\%$ without an approved committee exception.
* $\ge 90\%$ of the aggregate portfolio redeemable within five business days under ordinary conditions.


* **Assumptions Invented:**
* The 60/40 policy benchmark is treated as an unconstrained reference hurdle rather than an asset-allocation constraint; the actual policy asset weights may deviate heavily into short/intermediate fixed income, cash, or lower-volatility segments to protect capital.
* The CPI + 4% stated goal is subordinated whenever asset-class expected returns required to achieve it would force a portfolio risk level carrying a realistic risk of a $>10\%$ calendar-year drawdown.
* An operational "de-risking protocol" is assumed to trigger if portfolio drawdowns approach a predetermined internal floor (e.g., -6% to -8%) within any calendar year.


* **Validation Tests:**
* **Worst-Case Calendar-Year Drawdown Analysis:** Measure portfolio drawdowns across historical rising-rate, stagflationary, and equity-crash environments to verify that calendar-year drops do not breach 10%.
* **Required Return Shortfall Analysis:** Quantify the probability of failing to meet the CPI + 4% objective over rolling 5-year horizons as a direct tradeoff for preserving the 10% downside floor.
* **Cash Buffer & Depletion Run-Off Simulation:** Stress test how successive quarters of $750,000 distributions deplete the portfolio under prolonged periods of zero or negative capital growth.


* **CIO Question to Answer Before Optimization:**
* *"If mathematical optimization demonstrates that generating CPI + 4% net of costs cannot be achieved without taking on risk that permits a >10% calendar-year loss, does capital preservation take priority over meeting the real return objective?"*
