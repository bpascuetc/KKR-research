# Lab 13 — Portfolio Mandate Defense

Bernat Pascuet Cuesta · FIN 43900 · Prepared October 16, 2026 · Case as of October 15, 2026

**Status:** Lab date confirmed as Friday, October 16, 2026; session token supplied as “CFA investment.” Mandate and validation design prepared before optimization. The newly supplied Antigravity response is now preserved separately from Codex and evaluated in [TWO_SYSTEM_COMPARISON.md](TWO_SYSTEM_COMPARISON.md). The two-system comparison is complete for the supplied outputs. CIO approval, the before-AI process gap and personal attendance/attestation fields remain unresolved. No optimization, securities selection, backtest, pilot or trade has been performed.

## Decision and recommendation

The Meridian Foundation investment committee is the decision user, advised by its CIO. Its decision is whether to authorize analysis and a small pilot for the $100m reserve, not to execute trades today (F1). I recommend authorizing fact clarification and research design now, with optimization and pilot implementation gated on the committee selecting the loss interpretation and measurable tradeoff. Pilot size and authority must also be documented before implementation; “small” is not a numerical authorization.

I propose a loss-first research design: minimize the worst net calendar-year investment loss across a frozen scenario set, while reporting achievement and shortfall against CPI + 4% over rolling five-year periods. This is my proposed tradeoff for CIO consideration, not a preference supplied by the case. No optimizer may turn the missing preference into a default setting.

Evidence references F0–F11 refer to [the indexed case facts](CIO_FACTS.md), with the original screenshot preserved as [CIO_CASE.png](CIO_CASE.png). **Supported** means stated in the case or a direct calculation. **Requires clarification** marks a proposed convention or missing authority. **Unsupported** means the claim must be rejected as a case fact.

## Classification before operationalization

This classification was prepared with AI assistance after receiving the case. It is not evidence of the required unaided, before-AI exercise.

| Governing statement | Classification and disposition |
|---|---|
| $100m; committee authorizes analysis/small pilot, not trades (F1) | Decision boundary; **supported**. No pilot size is invented. |
| Seven years; quarterly review; annual rebalance (F2) | Policy/operational constraints; **supported**. A start/end date convention still needs approval. |
| CPI + 4%, net costs, rolling five years (F3) | Objective/aspiration, not guaranteed return; **supported**. |
| $750k quarterly; twelve-month cash/government reserve (F4) | Hard funding and reserve constraints; **supported**. |
| 60% global equities / 40% U.S. IG bonds (F5) | Policy benchmark, not mandatory portfolio weights; **supported**. |
| Long-only; no borrowing/shorts/derivatives (F6) | Hard implementation constraints; **supported**. |
| 8% issuer maximum (F7) | Hard concentration constraint; **supported**. Scope needs clarification. |
| 25% annual turnover unless documented committee exception (F7) | Governed operating limit; **supported**. No exception is presumed. |
| 90% within five business days, ordinary conditions (F8) | Hard ordinary-market liquidity constraint; **supported**. Not a crisis-liquidity guarantee. |
| No calendar-year loss greater than 10% (F9) | Strong loss-tolerance statement, operationally ambiguous. As a guaranteed market outcome it is an unverifiable promise; **requires clarification**. Do not quietly replace calendar-year loss with drawdown. |
| No sector, climate, social, tax, active or home-bias preference (F10) | No stated preference; **supported**. Do not invent screens or preferences. |
| Optimization tradeoff not chosen (F11) | Governance gap; **supported**. Proposed loss-first or probability objectives require approval. |

## Mandate boundaries and objective

- **User/action/timing:** Committee decides after mandate clarification whether to authorize research and a defined small pilot. As-of boundary is October 15, 2026 (F1).
- **Horizon:** Seven years from the eventually approved inception date; quarterly reviews and annual rebalancing (F2). Do not treat the five-year return measurement window as the policy horizon.
- **Universe proposal:** Unlevered, long-only exposures to broad global equities, U.S. investment-grade bonds, cash and daily-liquid government securities, pending committee approval (F4–F6). The benchmark informs this proposal but does not establish an exhaustive universe. No securities, fund tickers, sectors, illiquid allocations or KKR position are selected. Fund-level derivative use, currency exposure and issuer look-through require eligibility review; do not assume a fund label makes it compliant.
- **Return metric proposal:** Annualized, time-weighted net investment return over each rolling 60-month window, minus annualized CPI inflation over the same window, with a target spread of at least four percentage points (F3). Confirm CPI series, reporting currency and additive versus multiplicative convention. Report actual payout sufficiency separately: distributions are external cash flows, not investment losses.
- **Risk metric proposal:** Worst calendar-year net total investment return, excluding external distributions; maximum peak-to-trough drawdown is a separate diagnostic (F9). If the CIO means dollar asset depletion including payouts, the definition must change.
- **Tradeoff proposal:** Minimize worst calendar-year loss in the predeclared development/stress set, while reporting return-target attainment; do not silently turn the aspirational return target into a guaranteed hard constraint (F3/F9/F11). Absolute future capital protection is not established.

## Operational constraints and governing evidence

| Rule | Operational check | Evidence/status |
|---|---|---|
| Payout reserve | Next four scheduled quarterly payouts total 4 × $750,000 = **$3,000,000**, initially **3%** of $100m. Maintain that dollar reserve in cash/daily-liquid government securities, including after paying a quarter's distribution. Percentage rises if assets fall. | **Supported — F1/F4.** Reserve replenishment timing and source proposed for approval. |
| Quarterly distributions | Model $750k at each calendar quarter-end; test cash available before each payment and reserve after payment. Do not count an expected sale as already settled cash. | **Supported — F4**; settlement/replenishment convention **requires clarification**. |
| Ordinary liquidity | Eligible assets redeemable within five business days must be at least 90% of contemporaneous NAV; inspect terms, settlement and restrictions, not trading volume alone. | **Supported — F8**; calculation details proposed. |
| No borrowing, shorts or derivatives | Nonnegative weights; no cash overdraft, margin, short positions or derivative contracts. Check underlying fund use before admitting instruments. | **Supported — F6**; fund look-through scope **requires clarification**. |
| Issuer concentration | Each issuer exposure ≤8% of contemporaneous NAV. Obtain fund/look-through aggregation and government-issuer treatment before constructing the portfolio; no unstated government exemption. | **Supported limit — F7**; scope **requires clarification**. |
| Turnover | ≤25% each year absent a documented committee exception. Proposed measurement: 0.5 × sum of absolute traded dollar amounts / average NAV; report purchases/sales and flow-driven trades separately. Confirm treatment of initial funding and distribution sales. | **Supported limit — F7**; convention **requires clarification**. |
| Review/rebalance | Quarterly mandate/compliance review, annual rebalance; scheduled payouts do not imply quarterly strategic rebalancing. Ask for an emergency breach protocol. | **Supported — F2/F4**; emergency protocol not supplied. |
| Suitability | Admit instruments only after documenting reserve eligibility, issuer exposure, liquidity, fees and compatibility with F6. Add no ESG, sector, tax, active or home-bias screen. | **Supported absence of preferences — F10**; instrument approval remains proposed. |
| Loss tolerance | Record calendar-year -10% as a policy concern; do not label it guaranteed. Pending clarification, stop before optimization rather than assign an arbitrary breach probability. | **Supported statement — F9**; enforcement unresolved. |

The $3m reserve is a floor, not a complete liquidity solution. A full reserve is 3% initially; the 90% requirement is a separate portfolio-wide test. Government holdings may create an issuer-cap interaction under the literal 8% rule, so neither an exemption nor implementation feasibility is assumed.

## Benchmark and naive baseline

**Policy benchmark — supported F5:** 60% broad global equity total return / 40% U.S. investment-grade bond total return. Proposed annual rebalance convention follows F2; choose and freeze exact index series and currency before any performance inspection. Evaluate investment returns net of an explicitly disclosed implementation-cost estimate and simulate the same payout schedule when comparing funding feasibility. Label any gross published index comparison as gross.

**Naive baseline — proposed, requires approval:** A rules-based reserve-plus-benchmark comparator: hold the required next-twelve-month dollar reserve, then split the residual 60/40 between the two benchmark exposures. At inception only, the arithmetic is $3m reserve, $58.2m equity exposure and $38.8m bond exposure. These are a mechanical comparator definition, not an optimized or recommended policy allocation or security selection. Refill the reserve from liquid exposures in proportion to their holdings; count resulting trading/costs. Recheck eligibility, issuer limits, turnover and liquidity. Until actual exposures and measurement conventions are verified, call this a **candidate baseline**, not a proven compliant portfolio. Report the raw policy benchmark separately so its missing reserve is visible.

## Data boundary and precommitted validation

This design is recorded before fetching data or running models. No results have been inspected. The protocol below consists of **analyst proposals**, not additional supplied CIO facts. Freeze the approved mandate, data manifest and code version before calculation; changes become a new version with an explicit reason.

**Information cutoff:** October 15, 2026. Exclude subsequent publications, revised observations unavailable then, and knowledge of subsequent returns. Use point-in-time availability dates; CPI for a month cannot be used before its release. No external data have yet been downloaded. The screenshot supplies no return series or cost estimates.

**Proposed data manifest:** Monthly total-return series including reinvested distributions for approved global-equity, U.S. IG-bond and cash/government exposures; monthly CPI; instrument expense/transaction/settlement information and issuer/liquidity records. Record series names, currency, release/retrieval dates, source, vintage, missing values and any proxies. Do not backfill a young instrument with an undisclosed surviving fund. If daily liquidity/drawdown or settlement claims require daily/operational data, monthly returns alone are insufficient.

**Chronological split:** Development January 2006–December 2015; untouched holdout January 2016–December 2025, using only data available by the case cutoff. Both ten-year blocks permit rolling five-year analysis. Evaluate the seven-year policy horizon using fixed calendar-year inception cohorts within each block; in the holdout these are 2016–2022, 2017–2023, 2018–2024 and 2019–2025. They overlap and are dependent. The ten-year historical test block does not change the seven-year client horizon. January–October 2026 is excluded from model selection/testing in this version. If comparable data do not cover the declared periods, stop and record a revised protocol before inspecting performance; do not pick favorable replacement dates. Freeze the objective, candidate-selection rules, cost model and scenario definitions using development data; open the holdout once. No tuning after holdout failure. If any discretionary choices are revised, obtain a fresh evaluation design and disclose the used holdout.

| Precommitted test | Measurement and failure/action rule |
|---|---|
| Accounting, funding and compliance | Start simulated evaluation at $100m, charge actual estimated costs, pay $750k at calendar quarter-end and preserve the next-four-payout floor. Check instrument/issuer/turnover/ordinary-liquidity limits at each modeled review/payment/trade, with operational monitoring specified before pilot. Any breach without an authorized exception rejects that candidate. Missing settlement/eligibility data block a feasibility claim. |
| Objective and benchmark | Report every rolling 60-month annualized net return minus same-window annualized CPI, target shortfall magnitude/frequency, calendar losses, drawdown, costs and funding shortfalls for candidate, baseline and policy benchmark. Overlapping windows are dependent, not independent trials. No return target is promised. |
| Cost sensitivity | Include expenses once plus trading costs and reserve-refill trades. Before results, document an evidence-based base estimate. Test total cost burden +10 and +50 basis points per year over base. These increments are proposed stress choices, not case facts or claimed market estimates. A compliance/funding failure rejects; loss of claimed baseline advantage at +50bp removes the superiority claim and blocks pilot recommendation pending review. |
| Parameter perturbation | Where return estimates are used, shift each risky exposure's expected return by ±1 percentage point/year; multiply volatility by 0.75 and 1.25; raise cross-exposure correlations by 0.10 (cap below 1 and require a valid covariance matrix). Vary one factor and the adverse combination. These are analyst stress choices, not forecasts. Reject any resulting funding/compliance failure. If the stated advantage over the baseline reverses, do not recommend the complex candidate without new committee review. |
| Joint market stress | Illustrative instantaneous shocks: equity -30%, bonds -10%, reserve 0%; another scenario equity -15%, bonds -15%, reserve 0%, followed by scheduled payouts and costs. These are deliberately hypothetical proposed shocks. Report loss and liquidity, do not call them forecasts or calendar-year return observations. A >10% scenario loss flags the unresolved policy and blocks an unconditional loss-compliance claim. Hard rejection depends on the CIO's approved risk rule. |
| Holdout | Replay the frozen policy, same initial capital, distributions, costs and comparator conventions; report the same metrics without refitting. Any operational breach rejects. Failure of the predeclared primary objective relative to the candidate baseline means no evidence of improvement and no recommendation to advance that candidate. If CPI+4 is missed, disclose failure to attain the aspiration; seek committee review rather than relabel it as achieved. |
| Governance/feasibility gate | Missing approved objective, loss rule, universe, issuer/turnover definitions or necessary data means **no optimization/pilot implementation**. If return/loss/funding requirements cannot coexist, return an infeasibility finding to the committee, not looser constraints. |

The proposed primary comparison under Interpretation A is the candidate's worst calendar-year net loss versus the baseline, subject to compliance; a tie gives no demonstrated improvement. Report five-year return attainment as a separate tradeoff. A different CIO-approved objective requires a new precommitted decision rule before running anything. Stress robustness is evidence within a finite design, not proof that no future loss can exceed 10%.

## Two AI interpretations and their dispositions

The exact common request and System A's complete response are preserved in [SYSTEM_A_CODEX.md](SYSTEM_A_CODEX.md). It contains two materially different interpretations with claim-level evidence tags:

| Interpretation | Proposed objective | Unsupported inference rejected | My proposed disposition |
|---|---|---|---|
| A: loss-first | Minimize worst calendar-year loss; report the CPI+4 goal and target shortfalls. | A finite backtest can guarantee every future loss stays above -10%. | Retain as a discussion proposal; seek CIO approval of loss definition, scenario rule and priority before optimization. |
| B: target-probability | Maximize estimated five-year target-achievement probability subject to a CIO-selected annual loss-breach budget. | The analyst may invent a 5% breach probability or infer probability acceptance from the 10% statement. | Defer until the CIO explicitly accepts a probabilistic interpretation and chooses the budget; retain only as a contrasting alternative. |

Both preserve F2/F4/F6/F7/F8. Neither is an approved client mandate. Agreement between AI systems would not supply missing authority (F11).

**Actual second-system evidence:** Bernat supplied the new Google Antigravity response after receiving the prompt handoff. It is preserved without editorial additions in [SYSTEM_B_RAW.md](SYSTEM_B_RAW.md), separate from System A. This replaces recollection-only evidence for the current comparison; the earlier original remains lost. The underlying Antigravity model is not identified.

[The completed comparison](TWO_SYSTEM_COMPARISON.md) tags every material Antigravity claim as supported, unsupported or requires clarification, citing F0–F11. Its benchmark-tracker interpretation adds alpha, tracking error, policy bands and a 95%/99% confidence example; these cannot be adopted as CIO preferences. Its capital-preservation interpretation adds a -6% to -8% de-risking trigger and mixes calendar-year loss with drawdown. I retain the supplied operational constraints and a corrected loss-first discussion proposal; I defer the tracker formulation and reject invented rules and guaranteed-loss claims. Antigravity's proposed stress/simulation tests also omit an explicit untouched holdout, data cutoff and cost/failure protocol; my precommitted design supplies those rather than attributing them to the second system. Neither system's agreement resolves F9/F11.

## Escalation and decision reversal

**Primary unresolved ambiguity to escalate to the CIO/committee:** “When you say the reserve cannot lose more than 10% in a calendar year, do you mean a scenario limit, a probability budget, or a guaranteed outcome? Is loss measured as net investment return excluding distributions? Given that interpretation, which priority should govern when the CPI+4 objective conflicts with loss protection, and what breach response do you authorize?”

This is a proposed escalation question, not a message already delivered or a response already received. It directly addresses F9/F11. At minimum, loss enforcement and the optimized tradeoff need approval before optimization; instrument scope and measurement conventions must also be resolved before claiming a feasible mandate.

**Decision reversal fact:** A written committee answer explicitly approving a probabilistic loss budget and prioritizing five-year target-achievement probability would reverse the proposed loss-first formulation in favor of Interpretation B. Conversely, an explicit absolute guarantee requirement would block a risky pilot and require the committee to reconsider feasibility; neither cash nor government securities alone should be claimed to guarantee the net CPI+4 objective.

## 60-second defense — rehearsal draft

“My user is Meridian's investment committee. The decision is whether to authorize analysis and a small pilot for its $100 million reserve, not trades today. The horizon is seven years, with quarterly review and annual rebalancing. CPI plus four percent net over rolling five years is the goal, and global 60/40 is the benchmark. Four quarterly payments require a $3 million liquid reserve initially. The portfolio also needs 90 percent five-day liquidity, an 8 percent issuer cap, a 25 percent turnover limit, and no borrowing, shorts or derivatives. I propose a reserve-plus-benchmark baseline and tests fixed before results: chronological holdout, higher costs, market shocks and compliance checks. The unresolved issue is what the 10 percent loss statement means and which tradeoff takes priority. I will seek that answer before optimization; an AI cannot choose it for the CIO.”

## Participation, disclosure and remaining evidence

Bernat supplied the assignment and case and selected Codex as his AI learning partner. Codex transcribed the facts, drafted the mandate and alternatives, checked arithmetic and prepared the validation/defense materials. No other human teammate is claimed. Bernat reports using Google Antigravity, losing the first response, and then supplies a new response. That new response is now preserved and compared; the earlier lost text is not reconstructed. The human-first exercise was not evidenced before AI use; disclose this process gap and ask the instructor about an acceptable remedy rather than backdating work.

[BRIGHTSPACE_CHECKOUT_DRAFT.md](BRIGHTSPACE_CHECKOUT_DRAFT.md) includes the requested fields. The lab date and session token are supplied. The new second-system response and comparison are complete. Attendance declaration, personal truth attestation and actual submission receipt remain to be supplied/confirmed. Bernat requested first-person wording for the review and growth note; Codex drafted it without claiming an unaided personal reflection. No Brightspace or GitHub submission is claimed. The separate Project 2 Edition A pre-AI receipt is not supplied, not satisfied by this document, and no project-specific generative-AI work is performed here.

## Disclaimer

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
