# JPM — JPMORGAN CHASE & CO
SEC EDGAR | 10-K only | USD millions | latest filing per period/tag
ROE = net income / year-end equity; owner earnings = operating cash flow - capital spending.
| FY end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE % | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2021-12-31 | 121,649 | 48,334 | 78,084 | not found | 294,127 | 16.4% | not found |
| 2022-12-31 | 128,695 | 37,676 | 107,119 | not found | 292,332 | 12.9% | not found |
| 2023-12-31 | 158,104 | 49,552 | 12,974 | not found | 327,878 | 15.1% | not found |
| 2024-12-31 | 177,556 | 58,471 | -42,012 | not found | 344,758 | 17.0% | not found |
| 2025-12-31 | 182,447 | 57,048 | -147,782 | not found | 362,438 | 15.7% | not found |
- ROE at least 15% every year: **fail**
- Owner earnings positive every year: **not known**
- Owner earnings grew first to last: **not known**

### Tags and provenance — 2021-12-31
- revenue: us-gaap:Revenues; 2021-01-01 to 2021-12-31; filed 2024-02-16; accession 0000019617-24-000225; raw USD 121,649,000,000
- net_income: us-gaap:NetIncomeLoss; 2021-01-01 to 2021-12-31; filed 2024-02-16; accession 0000019617-24-000225; raw USD 48,334,000,000
- operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; 2021-01-01 to 2021-12-31; filed 2024-02-16; accession 0000019617-24-000225; raw USD 78,084,000,000
- capital_spending: not found; searched PaymentsToAcquirePropertyPlantAndEquipment, PaymentsToAcquireProductiveAssets
- equity: us-gaap:StockholdersEquity; 2021-12-31; filed 2024-02-16; accession 0000019617-24-000225; raw USD 294,127,000,000
- liabilities: us-gaap:Liabilities; 2021-12-31; filed 2023-02-21; accession 0000019617-23-000231; raw USD 3,449,440,000,000
- research_and_development: not found; searched ResearchAndDevelopmentExpense
- roe_percent: computed from NetIncomeLoss / StockholdersEquity * 100; no standalone XBRL tag.
- owner_earnings: computed from us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; no standalone XBRL tag.

### Tags and provenance — 2022-12-31
- revenue: us-gaap:Revenues; 2022-01-01 to 2022-12-31; filed 2025-02-14; accession 0000019617-25-000270; raw USD 128,695,000,000
- net_income: us-gaap:NetIncomeLoss; 2022-01-01 to 2022-12-31; filed 2025-02-14; accession 0000019617-25-000270; raw USD 37,676,000,000
- operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; 2022-01-01 to 2022-12-31; filed 2025-02-14; accession 0000019617-25-000270; raw USD 107,119,000,000
- capital_spending: not found; searched PaymentsToAcquirePropertyPlantAndEquipment, PaymentsToAcquireProductiveAssets
- equity: us-gaap:StockholdersEquity; 2022-12-31; filed 2025-02-14; accession 0000019617-25-000270; raw USD 292,332,000,000
- liabilities: us-gaap:Liabilities; 2022-12-31; filed 2024-02-16; accession 0000019617-24-000225; raw USD 3,373,411,000,000
- research_and_development: not found; searched ResearchAndDevelopmentExpense
- roe_percent: computed from NetIncomeLoss / StockholdersEquity * 100; no standalone XBRL tag.
- owner_earnings: computed from us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; no standalone XBRL tag.

### Tags and provenance — 2023-12-31
- revenue: us-gaap:Revenues; 2023-01-01 to 2023-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 158,104,000,000
- net_income: us-gaap:NetIncomeLoss; 2023-01-01 to 2023-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 49,552,000,000
- operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; 2023-01-01 to 2023-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 12,974,000,000
- capital_spending: not found; searched PaymentsToAcquirePropertyPlantAndEquipment, PaymentsToAcquireProductiveAssets
- equity: us-gaap:StockholdersEquity; 2023-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 327,878,000,000
- liabilities: us-gaap:Liabilities; 2023-12-31; filed 2025-02-14; accession 0000019617-25-000270; raw USD 3,547,515,000,000
- research_and_development: not found; searched ResearchAndDevelopmentExpense
- roe_percent: computed from NetIncomeLoss / StockholdersEquity * 100; no standalone XBRL tag.
- owner_earnings: computed from us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; no standalone XBRL tag.

### Tags and provenance — 2024-12-31
- revenue: us-gaap:Revenues; 2024-01-01 to 2024-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 177,556,000,000
- net_income: us-gaap:NetIncomeLoss; 2024-01-01 to 2024-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 58,471,000,000
- operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; 2024-01-01 to 2024-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD -42,012,000,000
- capital_spending: not found; searched PaymentsToAcquirePropertyPlantAndEquipment, PaymentsToAcquireProductiveAssets
- equity: us-gaap:StockholdersEquity; 2024-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 344,758,000,000
- liabilities: us-gaap:Liabilities; 2024-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 3,658,056,000,000
- research_and_development: not found; searched ResearchAndDevelopmentExpense
- roe_percent: computed from NetIncomeLoss / StockholdersEquity * 100; no standalone XBRL tag.
- owner_earnings: computed from us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; no standalone XBRL tag.

### Tags and provenance — 2025-12-31
- revenue: us-gaap:Revenues; 2025-01-01 to 2025-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 182,447,000,000
- net_income: us-gaap:NetIncomeLoss; 2025-01-01 to 2025-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 57,048,000,000
- operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; 2025-01-01 to 2025-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD -147,782,000,000
- capital_spending: not found; searched PaymentsToAcquirePropertyPlantAndEquipment, PaymentsToAcquireProductiveAssets
- equity: us-gaap:StockholdersEquity; 2025-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 362,438,000,000
- liabilities: us-gaap:Liabilities; 2025-12-31; filed 2026-02-13; accession 0001628280-26-008131; raw USD 4,062,462,000,000
- research_and_development: not found; searched ResearchAndDevelopmentExpense
- roe_percent: computed from NetIncomeLoss / StockholdersEquity * 100; no standalone XBRL tag.
- owner_earnings: computed from us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; no standalone XBRL tag.


## Additional shared facts
| FY end | Liabilities, USD millions | R&D, USD millions | R&D / revenue | Liabilities / equity |
|---|---:|---:|---:|---:|
| 2021-12-31 | 3,449,440 | not found | not known | 11.73 |
| 2022-12-31 | 3,373,411 | not found | not known | 11.54 |
| 2023-12-31 | 3,547,515 | not found | not known | 10.82 |
| 2024-12-31 | 3,658,056 | not found | not known | 10.61 |
| 2025-12-31 | 4,062,462 | not found | not known | 11.21 |

Revenue growth a year, first to last: 10.66%.
Formula: (last revenue / first revenue)^(1/4) - 1; five fiscal observations.
Active growth threshold: 15%; active R&D threshold: 5%.
Burry leverage ceiling: 2 times positive equity.

## Panel checks
| Investor | Check | Result |
|---|---|---|
| Buffett | ROE at least 15% every year | fail |
| Buffett | Owner earnings positive every year | not known |
| Buffett | Owner earnings grew first to last | not known |
| Cathie Wood | Revenue grew at least 15% a year first to last | fail |
| Cathie Wood | Latest R&D at least 5% of revenue | not known |
| Burry | Operating cash flow at least net income every year | fail |
| Burry | Latest liabilities no more than twice equity | fail |

Values are not price valuations. Not found is not zero; not known is not pass.
I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
