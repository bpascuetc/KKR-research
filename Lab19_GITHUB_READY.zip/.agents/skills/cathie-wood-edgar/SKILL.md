---
name: cathie-wood-edgar
description: Run Lab19's Cathie Wood-inspired revenue-growth and R&D screen on the shared five-year SEC 10-K evidence, then write a number-audited innovation memo. Excludes price targets and claims about her actual trades.
---

Use the Lab19 root containing `panel.py`, `evidence/` and this `.agents/skills` directory.
Run `python panel.py TICKER --offline` for saved SEC companyfacts; for a new ticker use
`--user-agent "Full Name real-email"` with the user's real SEC contact. Do not guess it.
Read `evidence/TICKER_panel_printed.md` before writing a judgment. The shared extractor
preserves Lab18's tags, annual USD 10-K rules, fiscal ends, latest filings and unknowns;
the only additional tags are `Liabilities` and `ResearchAndDevelopmentExpense`.

The skill's [config.json](config.json) sets revenue growth at 15% and latest R&D/revenue at 5%.
[scripts/cathie_checks.py](scripts/cathie_checks.py) implements both checks. Five annual
observations span four intervals: `(last revenue / first revenue) ** (1/4) - 1`.
Missing endpoints or invalid denominators yield “not known”; absent R&D stays “not found”.
For the threshold probe, change growth_threshold_percent in this skill's config.json to 5,
run the panel, record the changed check, then restore the chosen threshold. Do not change facts.

Read [FAskills' Cathie Wood page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/cathie_wood.md)
for the innovation/reinvestment lens. The lab's narrower rules override its forecasts, prices,
scores and holdings prompts. Do not install FAskills or invent innovation evidence.
Write a short explicitly Cathie Wood-inspired classroom memo, not her actual opinion,
with **Verdict: ...** and only financial numbers printed by the script. Distinguish a screen
from proof of future disruption. Preserve failed and unknown checks in the explanation.
Under the memo record the threshold kept and why; label it an AI-enhanced draft pending student review.

Run `python panel.py TICKER --offline --audit`; fix unsupported numbers rather than expanding
the numeric allowlist. A saved memo has a sibling `.source.json` with `fingerprint` from
`memo_fingerprint(result, 'Cathie Wood')`; mismatches must be disclosed as stale. The app
uses saved model memos and never represents a Python template as a fresh AI judgment.
Keep the exact disclaimer printed by the script at the end of the memo.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
