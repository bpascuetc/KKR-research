"""Cathie Wood classroom checks. Missing facts never become estimates."""
import json
import math
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[1] / 'config.json'


def configuration():
    config = json.loads(CONFIG.read_text())
    for key in ('growth_threshold_percent', 'rd_threshold_percent'):
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f'{key} must be a finite nonnegative number.')
    return config


def cathie_checks(rows, config=None):
    config = configuration() if config is None else config
    first = rows[0]['revenue'] if len(rows) == 5 else None
    last = rows[-1]['revenue'] if len(rows) == 5 else None
    # Five fiscal observations span four annual growth intervals.
    growth = None
    if first is not None and last is not None and first > 0 and last >= 0:
        growth = ((last / first) ** (1 / 4) - 1) * 100
    latest = rows[-1] if rows else {}
    rd, revenue = latest.get('research_and_development'), latest.get('revenue')
    intensity = None if rd is None or revenue is None or revenue <= 0 else rd / revenue * 100
    growth_status = 'not known' if growth is None else ('pass' if growth >= config['growth_threshold_percent'] else 'fail')
    rd_status = 'not known' if intensity is None else ('pass' if intensity >= config['rd_threshold_percent'] else 'fail')
    return {
        'metrics': {'revenue_growth_percent': growth, 'latest_rd_percent': intensity},
        'checks': {
            f"Revenue grew at least {config['growth_threshold_percent']:g}% a year first to last": growth_status,
            f"Latest R&D at least {config['rd_threshold_percent']:g}% of revenue": rd_status,
        },
        'config': config,
    }
