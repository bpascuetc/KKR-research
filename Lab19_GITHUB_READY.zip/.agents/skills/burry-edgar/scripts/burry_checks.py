"""Burry classroom checks; total liabilities, not only borrowings."""


def burry_checks(rows):
    complete = len(rows) == 5 and all(
        r['operating_cash_flow'] is not None and r['net_income'] is not None for r in rows)
    cash = 'not known' if not complete else (
        'pass' if all(r['operating_cash_flow'] >= r['net_income'] for r in rows) else 'fail')
    latest = rows[-1] if rows else {}
    liabilities, equity = latest.get('liabilities'), latest.get('equity')
    leverage = None if liabilities is None or equity is None or equity <= 0 else liabilities / equity
    return {
        'metrics': {'latest_liabilities_to_equity': leverage},
        'checks': {
            'Operating cash flow at least net income every year': cash,
            'Latest liabilities no more than twice equity': 'not known' if leverage is None else ('pass' if leverage <= 2 else 'fail'),
        },
    }
