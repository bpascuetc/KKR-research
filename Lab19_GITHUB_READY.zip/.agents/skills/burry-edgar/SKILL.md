---
name: burry-edgar
description: Run Lab19's Burry-inspired cash-versus-income and liabilities-to-equity checks on shared five-year SEC 10-K facts, then write a number-audited skeptical memo. Excludes price valuation, short recommendations and actual investor opinions.
---

Use the Lab19 root containing `panel.py`, `evidence/` and this `.agents/skills` directory.
Run `python panel.py TICKER --offline` on saved SEC downloads, or use the user's actual
SEC name/email with `--user-agent` for a new download. Read `evidence/TICKER_panel_printed.md`.
Reuse the shared Lab18 annual USD 10-K facts and rules; use only the added prescribed
`Liabilities` tag for total liabilities. No substitutes or estimated gaps.

[scripts/burry_checks.py](scripts/burry_checks.py) checks OCF at least net income in every
displayed year and latest liabilities no more than twice positive year-end equity.
Incomplete annual cash/income history, missing liabilities or nonpositive equity makes the
relevant check “not known”. A cash pass does not prove clean accounts or absence of hidden claims.

Read [FAskills' Burry page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md)
for the skeptical cash-quality lens. Apply the lab's narrower checks rather than its prompts
for price targets, scores, allegations or current holdings. Do not install FAskills.
Write an explicitly Burry-inspired classroom memo, not his actual view, with **Verdict: ...**.
Use printed financial numbers only; explain what cash coverage and leverage do and do not establish.
Never turn an unknown into a pass, infer fraud from a failed screen or claim footnotes were reviewed.

Validate using `python panel.py TICKER --offline --audit`; correct unsupported tokens.
Record `memo_fingerprint(result, 'Burry')` in the memo's sibling `.source.json`; changed
facts invalidate an old memo. Numeric presence is not a semantic audit. Append the exact
student/AI disclaimer printed by the script. App memos are saved AI judgments, not new agent calls.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
