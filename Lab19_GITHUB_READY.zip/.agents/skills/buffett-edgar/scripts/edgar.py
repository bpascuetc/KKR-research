"""Keyless SEC facts; deterministic Lab18 calculations, never inferred inputs."""
import argparse
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
from pathlib import Path
import re
import ssl
import time
from urllib.request import Request, urlopen

DISCLAIMER = ('I am a student, not a financial professional. This document was prepared for '
              'FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. '
              'It is not professional investment research or financial advice. I used OpenAI '
              'Codex to help with research, analysis, calculations, and drafting. '
              'Any remaining errors are my own.')
TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues'],
    'net_income': ['NetIncomeLoss'],
    'operating_cash_flow': ['NetCashProvidedByUsedInOperatingActivities'],
    'capital_spending': ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
    'equity': ['StockholdersEquity'],
}
TICKERS_URL = 'https://www.sec.gov/files/company_tickers.json'


def annual(fact):
    """One fiscal year, including 52/53-week years, rather than a quarter/YTD."""
    try:
        days = (date.fromisoformat(fact['end']) - date.fromisoformat(fact['start'])).days
        return fact.get('form') == '10-K' and 335 <= days <= 395
    except (KeyError, ValueError):
        return False


def candidates(facts, tag, end=None, instant=False):
    entries = facts.get('facts', {}).get('us-gaap', {}).get(tag, {}).get('units', {}).get('USD', [])
    return [f for f in entries if f.get('form') == '10-K'
            and (end is None or f.get('end') == end)
            and (('start' not in f) if instant else annual(f))]


def select_fact(facts, metric, end):
    """Apply prescribed tag priority, then latest filing for this exact end."""
    for tag in TAGS[metric]:
        options = candidates(facts, tag, end, instant=metric == 'equity')
        if options:
            chosen = max(options, key=lambda f: (f.get('filed', ''), f.get('accn', ''), f.get('start', '')))
            return {**{k: chosen.get(k) for k in ('val', 'start', 'end', 'filed', 'accn', 'form')},
                    'tag': 'us-gaap:' + tag, 'unit': 'USD'}
    return {'val': None, 'tag': 'not found', 'end': end, 'searched_tags': TAGS[metric]}


def year_row(facts, end):
    """Turn EDGAR facts into one row; missing inputs stay missing."""
    selected = {metric: select_fact(facts, metric, end) for metric in TAGS}
    values = {metric: item['val'] for metric, item in selected.items()}
    ni, equity = values['net_income'], values['equity']
    ocf, capex = values['operating_cash_flow'], values['capital_spending']
    roe = None if ni is None or equity is None or equity <= 0 else ni / equity * 100
    owner = None if ocf is None or capex is None else ocf - capex
    return {'fiscal_year_end': end, **values, 'roe_percent': roe, 'owner_earnings': owner,
            'sources': selected,
            'derived_tags': {'roe_percent': 'NetIncomeLoss / StockholdersEquity * 100',
                             'owner_earnings': selected['operating_cash_flow']['tag'] + ' - ' + selected['capital_spending']['tag']}}


def checks(rows):
    def every(field, predicate):
        if len(rows) != 5 or any(r[field] is None for r in rows):
            return 'not known'
        return 'pass' if all(predicate(r[field]) for r in rows) else 'fail'
    growth = 'not known'
    if len(rows) == 5 and rows[0]['owner_earnings'] is not None and rows[-1]['owner_earnings'] is not None:
        growth = 'pass' if rows[-1]['owner_earnings'] > rows[0]['owner_earnings'] else 'fail'
    return {'ROE at least 15% every year': every('roe_percent', lambda x: x >= 15),
            'Owner earnings positive every year': every('owner_earnings', lambda x: x > 0),
            'Owner earnings grew first to last': growth}


def analyze(facts, ticker):
    # Annual flow ends define fiscal years. Never use the fact's `fy`: it labels
    # the filing year, which can differ from the comparative fact's actual year.
    ends = sorted({f['end'] for tags in TAGS.values() for tag in tags
                   for f in candidates(facts, tag)})[-5:]
    if not ends:
        raise ValueError('No annual USD 10-K flow periods found for the prescribed tags.')
    rows = [year_row(facts, end) for end in ends]
    return {'ticker': ticker.upper(), 'entity': facts.get('entityName', ''), 'cik': facts.get('cik'),
            'rows': rows, 'checks': checks(rows)}


def money(value):
    return 'not found' if value is None else f'{value / 1_000_000:,.0f}'


def report(result):
    lines = [f"# {result['ticker']} — {result['entity']}",
             'SEC EDGAR | 10-K only | USD millions | latest filing per period/tag',
             'ROE = net income / year-end equity; owner earnings = operating cash flow - capital spending.',
             '| FY end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE % | Owner earnings |',
             '|---|---:|---:|---:|---:|---:|---:|---:|']
    for row in result['rows']:
        vals = [row['fiscal_year_end']] + [money(row[k]) for k in TAGS]
        vals += ['not known' if row['roe_percent'] is None else f"{row['roe_percent']:.1f}%", money(row['owner_earnings'])]
        lines.append('| ' + ' | '.join(vals) + ' |')
    for name, outcome in result['checks'].items():
        lines.append(f'- {name}: **{outcome}**')
    for row in result['rows']:
        lines.append('\n### Tags and provenance — ' + row['fiscal_year_end'])
        for metric, source in row['sources'].items():
            if source['val'] is None:
                lines.append(f"- {metric}: not found; searched " + ', '.join(source['searched_tags']))
            else:
                period = (source.get('start') + ' to ') if source.get('start') else ''
                lines.append(f"- {metric}: {source['tag']}; {period}{source['end']}; filed {source['filed']}; accession {source['accn']}; raw USD {source['val']:,}")
        for name, formula in row['derived_tags'].items():
            lines.append(f'- {name}: computed from {formula}; no standalone XBRL tag.')
    return '\n'.join(lines) + '\n\n' + DISCLAIMER + '\n'


NUMBER = re.compile(r'(?<![\d.,])(?:\d{4}-\d{2}-\d{2}|[+−-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s*%?)(?!\d|[,.]\d)')


def numeric_tokens(text):
    output = []
    for match in NUMBER.finditer(text):
        raw = match.group().strip()
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', raw):
            key = ('date', raw)
        else:
            percent = raw.endswith('%')
            try:
                key = ('percent' if percent else 'number', Decimal(raw.rstrip('%').strip().replace(',', '').replace('−', '-')))
            except InvalidOperation:
                continue
        output.append((raw, key))
    return output


def unsupported_numbers(memo, printed):
    allowed = {key for _, key in numeric_tokens(printed)}
    return list(dict.fromkeys(raw for raw, key in numeric_tokens(memo) if key not in allowed))


def download(url, target, user_agent):
    if not re.search(r'[^\s@]+@[^\s@]+\.[^\s@]+', user_agent) or len(user_agent.split()) < 2:
        raise ValueError('SEC User-Agent must name you and include your real email.')
    context = ssl.create_default_context()
    try:
        import certifi
        context = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        pass
    req = Request(url, headers={'User-Agent': user_agent, 'Accept': 'application/json'})
    with urlopen(req, timeout=60, context=context) as response:
        raw = response.read()
    parsed = json.loads(raw)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    metadata = {'url': url, 'retrieved_at': datetime.now(timezone.utc).isoformat(),
                'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    target.with_suffix('.source.json').write_text(json.dumps(metadata, indent=2) + '\n')
    time.sleep(0.2)
    return parsed


def run(ticker, output_dir, user_agent='', offline=False):
    ticker = ticker.strip().upper()
    if not re.fullmatch(r'[A-Z0-9][A-Z0-9.\-]{0,14}', ticker):
        raise ValueError('Enter a ticker using letters, numbers, dots or hyphens.')
    output_dir = Path(output_dir)
    if offline:
        facts = json.loads((output_dir / f'{ticker}_companyfacts.json').read_text())
    else:
        tickers = download(TICKERS_URL, output_dir / 'company_tickers.json', user_agent)
        matches = [v for v in tickers.values() if v['ticker'].upper() == ticker]
        if not matches:
            raise ValueError('Ticker not found in SEC company_tickers.json.')
        cik = int(matches[0]['cik_str'])
        facts = download(f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json',
                         output_dir / f'{ticker}_companyfacts.json', user_agent)
    result = analyze(facts, ticker)
    (output_dir / f'{ticker}_results.json').write_text(json.dumps(result, indent=2) + '\n')
    (output_dir / f'{ticker}_printed.md').write_text(report(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ticker')
    parser.add_argument('--output-dir', type=Path, default=Path('evidence'))
    parser.add_argument('--user-agent', default=os.getenv('SEC_USER_AGENT', ''))
    parser.add_argument('--offline', action='store_true', help='Use saved SEC JSON, not invented fixtures')
    parser.add_argument('--memo', type=Path, help='Validate every numeric token against printed output')
    args = parser.parse_args()
    try:
        result = run(args.ticker, args.output_dir, args.user_agent, args.offline)
        printed = report(result)
        print(printed)
        if args.memo:
            flagged = unsupported_numbers(args.memo.read_text(), printed)
            print('Unsupported memo numbers: ' + (', '.join(flagged) if flagged else 'none'))
            if flagged:
                raise SystemExit(2)
    except (ValueError, OSError) as error:
        parser.exit(1, f'Error: {error}\n')


if __name__ == '__main__':
    main()
