---
name: buffett-edgar
description: Evaluate a ticker as a Buffett-style business using five annual SEC 10-K periods, deterministic owner-earnings checks and a number-audited memo. Use for Lab18 or requests to run this business-quality screen; excludes stock-price valuation.
---

Run the bundled `scripts/edgar.py TICKER --output-dir PATH --user-agent "Full Name email"`.
Use the user's actual name/email; ask for missing contact information. No API key is needed.
For reproducible archived evidence, add `--offline` with a directory holding downloaded companyfacts.
Read `TICKER_printed.md` before judging. All financial numbers and checks must come from this script.

The script restricts inputs to USD 10-K facts, annual flows, the last five fiscal-year-end dates,
prescribed tags with ordered fallbacks, and the latest filing within each period/tag. Never use
filing `fy` to relabel comparative facts. Preserve tags, accession numbers and download hashes.
Revenue: RevenueFromContractWithCustomerExcludingAssessedTax then Revenues. Net income:
NetIncomeLoss. OCF: NetCashProvidedByUsedInOperatingActivities. Capex:
PaymentsToAcquirePropertyPlantAndEquipment then PaymentsToAcquireProductiveAssets.
Equity: StockholdersEquity. ROE uses year-end equity; nonpositive equity makes ROE unknown.
Owner earnings use OCF minus capex, the lab's simplified proxy. Missing values stay “not found”;
checks with missing required inputs are “not known”. Do not substitute other tags to fill a gap.
The code tests ROE at least 15% throughout, positive owner earnings throughout, and endpoint growth.

Read the philosophy at https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md
when interpreting the screen. Never install FAskills or use its paid data services. Apply its
business-ownership lens, but the lab's narrower formulas and no-price scope take precedence.

Write `memos/TICKER_memo.md` as an explicitly Buffett-inspired classroom simulation, not his
actual opinion. Choose **own the business**, **watch it**, or **pass**. Use only numbers printed
by the script, with their displayed units/rounding. Explain limitations: these checks alone do
not establish a durable moat, management quality, or a sensible purchase price. If owner earnings
are unavailable, say you cannot judge owner earnings. No price data, forecasts, invented scores,
or mental arithmetic. Append a clearly labeled AI-enhanced draft student trust decision for
student review rather than claiming a personal judgment was supplied. End with the exact
student/AI disclaimer printed by the script.

Validate with `scripts/edgar.py TICKER --output-dir PATH --offline --memo memos/TICKER_memo.md`.
Fix unsupported numeric tokens rather than expanding the allowlist. The audit proves numeric
presence only; independently check metric/year/unit attribution and causal claims. Unknown or
failed checks cannot silently become passes. Report actual live differences from classroom
anchors; never hard-code the answer table into extraction or relabel fixtures as EDGAR evidence.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
