# Lab 14 source review for updated Lab 15

The saved Lab14 folder does exist: ../../Lab14/2026-10-21/. Rechecked its Markdown report, Python calculator, CSV/JSON results, assignment screenshot and all entries of Lab14_PREPARATION.zip. The ZIP also includes Lab13 reference facts/screenshot. These artifacts implement the older 25-anonymous-asset baseline exercise. None provides the updated four-sleeve bills/10-year/IG/equity returns, volatilities or correlation table.

Also searched the course directory, Desktop, Documents and Downloads for Lab14/portfolio/mandate/prices files. Inspected all three Week3_Portfolio_Optimization notebook variants in Downloads: those use AAPL/MSFT/JNJ/XOM/PG daily data and a maximum-Sharpe exercise, not the Meridian four-sleeve table. The separate Bernat Pascuet Fin 439 course folder contains template notes/readings, not that table. No previously saved Project2 fund mandate or prices.csv was found.

The updated screenshots give rounded output anchors and the 8% equity mean but not the underlying volatility/correlation table. Do not fabricate that table or treat the 25 anonymous returns as the four named sleeves. Updated Meridian verification remains explicitly unexecuted pending the actual course table. The separate three-fund VTI/BND/SGOV calculation now uses real downloaded adjusted prices.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
