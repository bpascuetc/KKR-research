# Updated Lab15 validation

Seven automated tests pass using unittest and Streamlit AppTest: independent grid-search enumeration, known numerical reserve/minimum-variance cases, infeasible outcomes, covariance rejection, price estimation and invalid data, missing-input UI, uploaded synthetic CSV/all-versus-36-month UI, edited-return/shared-engine mutation behavior. Fixtures are expressly synthetic test data, never course inputs or investment evidence. Initial cold AppTest hit its default three-second timeout; setting a 30-second allowance resolved it. No calculation failure was hidden.

Streamlit was started on http://127.0.0.1:8501 and its health endpoint returned `ok`. Local socket/network sandbox restrictions required approved commands; the app is bound to localhost. This confirms startup, while AppTest checks cover interactions.

Actual Meridian assignment anchor tests remain blocked by missing four-sleeve inputs. The user authorized selecting three funds. VTI/BND/SGOV adjusted prices were downloaded and all-60-month, last-36-month, one-point-return, reserve and cost diagnostics now execute successfully under an explicitly proposed 6.5% objective/3% SGOV reserve-proxy scenario. The independent Project 2 mandate is not established by those assumptions. updated_results.json records both executed diagnostics and the blocked training table. All seven tests passed again after bundling prices and updating the app to load them. Saved Lab14 outputs are reprinted for continuity, not claimed as four-sleeve validation. No upload, attendance or partner activity claimed.

Run `python -m unittest test_engine -v` and `python run_evidence.py` from this folder. App testing follows [Streamlit AppTest documentation](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest).

Eight tests now pass after adding the Four-sleeve practice option. The new UI test verifies explicit proxy labeling, computed allocation and one-point response against the shared engine. Real four-proxy data checks pass: symmetry/PSD, direct-versus-matrix baseline variances, normalized nonnegative weights and the expressly AI-provided elementary covariance example. Practice is not official course-table verification.

October22 final update: Bernat explicitly confirms Meridian verified and the Project2 mandate verified; STUDENT_CONFIRMATIONS.json records both. The original course input table is still absent locally, so local replay status and student confirmation remain separate. The app now opens on bundled three-fund data and displays the confirmed mandate. All eight tests pass after these changes; local health endpoint returned `ok`. User handles GitHub; no upload/submission or unreported independent/partner activity claimed.

Charts update: added interactive allocation comparison and annual risk/return estimate charts with objective line. All eight tests pass, including an assertion that both charts are emitted on a feasible uploaded-price run; controls, window, edits and infeasibility continue to pass. Charts consume shared-engine results.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.

