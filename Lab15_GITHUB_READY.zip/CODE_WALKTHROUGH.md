# My engine explanation and discussion preparation

AI-enhanced supporting preparation. Bernat subsequently confirmed that his personal drawing, code explanation and partner attack happened; his partner works on Accenture. The exact exchange details are not supplied here.

## My plain-language explanation

I use VTI for U.S. equities, BND for broad U.S. bonds and SGOV for the reserve sleeve. My objective is an estimated annual return of at least 6.5%, with at least 3% in SGOV, no short positions and weights totaling 100%. I search only five-percentage-point allocations and select the feasible mix with the lowest estimated volatility.

I start with monthly adjusted prices, turn each pair into a monthly simple return, estimate annual returns and covariance, and search feasible allocations. The Streamlit page calls those functions from portfolio.py; it does not maintain a second copy of the optimizer. The Mermaid chart in README.md shows the same route. I should draw my own paper version before consulting it if I am completing the assignment's no-AI drawing step.

## search(), line by line

1. `validate_inputs(...)` checks return dimensions, numeric values, covariance symmetry/positive-semidefiniteness and one reserve flag per asset. Bad data raises an error; it is not silently repaired.
2. The objective and reserve minimum are checked for finite values; the minimum must be between 0 and 1.
3. `compositions(20, len(mu))` generates every nonnegative integer allocation totaling 20 units. Each unit represents 5%of the portfolio. For 3 funds there are 231 mixes; for 4 sleeves there are1,771.
4. `weights = units / 20` converts those integers to decimal weights. Every row is fully invested and long only by construction.
5. `expected = weights @ mu` calculates each mix's expected return estimate.
6. `reserves = weights @ reserve_eligible` adds the weights of assets designated eligible by the mandate.
7. `valid` keeps only mixes with return at least the objective and reserve weight at least the minimum. A tiny numerical tolerance handles floating-point arithmetic, not economically meaningful violations.
8. If no row passes, the function returns `None`. The app displays no feasible grid mix; it never lowers the objective to manufacture one.
9. `np.einsum(...)` computes w′Σw for every surviving mix, using all covariances rather than only individual volatilities.
10. `np.argmin(...)` selects the lowest-variance mix; exact ties keep the first lexicographic allocation.
11. The function returns its weights, return estimate, square-root volatility, reserve weight and counts of tested/feasible mixes.

## What estimate() does

I require 3–6 ticker columns after a date column. Prices must be positive, finite, chronologically ordered and monthly without gaps. I compute P[t]/P[t−1]−1, use all returns or the last 36 returns, annualize arithmetic means and sample covariances by 12, and derive volatilities/correlations. A 36-return window requires 37 price observations. Adjusted closes reflect provider distribution/split conventions; the source dates and file hashes are preserved.

## A question I should be able to answer

**Why can a lower equity estimate produce a higher equity allocation?** My return constraint stays fixed. Lowering VTI's mean makes the previous 30%equity mix fail the 6.5%threshold, so the engine needs 35%equity to reach it; it is not a rule that lower return estimates always mean lower allocations.

**Why does BND receive zero weight?** In this sample, its mean and covariance do not help achieve this particular minimum-variance/return-threshold solution relative to SGOV and VTI. That is not a general claim that bonds have no role.

**Why is the reserve minimum 3% but the grid uses 5% steps?** Any positive reserve weight on this grid must be at least 5%. The engine does not round the mandate down.

## My two-sentence stress response — ready to discuss

“When I reduce VTI's expected annual return by one percentage point, my lowest-risk feasible mix moves from 30% VTI / 70% SGOV to 35% VTI / 65% SGOV, and estimated volatility rises from 4.85% to 5.64%. I would reject adoption for now because this sensitivity, together with the 15 percentage-point window change, shows that my starting allocation depends materially on uncertain estimates; I would reconsider after fresh validation supports the allocation under my verified mandate.”

This describes the executed assistant-run stress. It is not a fabricated statement that a partner chose the input or performed an attack. My real partner discussion happened, as I confirmed; his universe was BIL/IEF/LQD/VT and he also tested a one-percentage-point estimate change. My finalized review response is in CHECKOUT.md. It does not invent his exact input or numerical outcome. Session token, contribution and attendance remain my own entries.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
