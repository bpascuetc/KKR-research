"""Capture actual engine outputs; blocked inputs remain blocked, not fabricated."""
import json
from pathlib import Path
from portfolio import load_meridian,meridian_checks,estimate,search,largest_change
P=Path(__file__).resolve().parent
out={'version':'updated_streamlit_lab15','meridian':{},'project2':{}}
try:out['meridian']=meridian_checks(load_meridian())
except ValueError as e:out['meridian']={'status':'BLOCKED_MISSING_COURSE_TABLE','reason':str(e)}
m=json.loads((P/'project2_mandate.json').read_text())
if not (P/'prices.csv').exists() or m['objective_annual_decimal'] is None or m['reserve_minimum'] is None or m['reserve_eligible'] is None:
 out['project2']={'status':'BLOCKED_MISSING_MANDATE_OR_PRICES','reason':'Need actual 3–6 funds, numeric objective, hard constraint/reserve rule and sourced adjusted prices.'}
else:
 try:
  full=estimate(P/'prices.csv');short=estimate(P/'prices.csv',True)
  if full['labels']!=m['tickers']:raise ValueError('Mandate ticker order must match price columns.')
  if len(m['reserve_eligible'])!=len(m['tickers']):raise ValueError('Reserve flags do not match mandate tickers.')
  obj=m['objective_annual_decimal'];minimum=m['reserve_minimum'];eligible=m['reserve_eligible']
  a=search(full['returns'],full['covariance'],eligible,obj,minimum);b=search(short['returns'],short['covariance'],eligible,obj,minimum)
  tightened=search(full['returns'],full['covariance'],eligible,obj,min(1,minimum+.05))
  cost=search([v-.0025 for v in full['returns']],full['covariance'],eligible,obj,minimum)
  for stress in (tightened,cost):
   if a and stress:assert stress['volatility']>=a['volatility']-1e-12
  changed_mu=list(full['returns']);changed_mu[0]-=.01
  onepoint=search(changed_mu,full['covariance'],eligible,obj,minimum)
  out['project2']={'one_point_lower_VTI':onepoint,'one_point_largest_change_pp':largest_change(a,onepoint),'status':'EXECUTED_DIAGNOSTIC_ONLY','mandate':m,'all_month_estimates':full,'last36_estimates':short,'all_months':a,'last36':b,'largest_change_pp':largest_change(a,b),'reserve_plus5pp':tightened,'flat_annual_cost25bp':cost}
 except ValueError as e:out['project2']={'status':'BLOCKED_INVALID_INPUT','reason':str(e)}
if (P/'lab14_four_sleeve_results.json').exists():
 out['four_sleeve_practice']=json.loads((P/'lab14_four_sleeve_results.json').read_text())
if (P/'STUDENT_CONFIRMATIONS.json').exists():
 out['student_confirmations']=json.loads((P/'STUDENT_CONFIRMATIONS.json').read_text())
(P/'updated_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
