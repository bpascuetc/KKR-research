# How I check the app

## Open it

If the local server is running, open **http://127.0.0.1:8501** in a browser on this Mac. Keep the terminal/server running while using it. “Localhost” is this computer; it is not a public hosting link.

If it is not running, open Terminal and paste:

```bash
cd /Users/bernatpascuetcuesta/Documents/Courses/AIFinance2026/BernatPascuete/Lab15/2026-10-22/updated_app
../.venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --browser.gatherUsageStats false
```

Then open the local address. If that port is already in use, the existing server may already be running; open its address before starting a second copy. Control-C stops a server in its terminal.

## Check my three-fund result

1. In the sidebar, choose **My fund prices**. The bundled prices load automatically; uploading prices.csv is optional for checking the included snapshot.
2. Keep the objective at **6.5%** and reserve minimum at **3%**. SGOV should be the only reserve-eligible asset checked.
3. Leave **Use last 36 monthly returns** unchecked. Do not edit the return boxes yet. Expect **30% VTI / 0% BND / 70% SGOV**, return estimate **6.54%**, volatility estimate **4.85%**. Both side-by-side panels should agree; largest weight change should be zero.
4. Check **Use last 36 monthly returns**. Expect **15% VTI / 0% BND / 85% SGOV**, return estimate **6.94%**, volatility estimate **1.97%**. The as-loaded panel remains the all-month comparison. Largest weight change should read **15.00 percentage points**.
5. Uncheck the switch. Lower VTI's expected annual return by exactly one percentage point, from approximately **13.134229% to 12.134229%** (subtract 1.00 from the number shown; do not round it to 12.13 if checking exact inputs). Expect **35% VTI / 0% BND / 65% SGOV**, return estimate **6.66%**, volatility estimate **5.64%**, largest weight change **5.00 points**. The reference panel should still show 30/0/70.
6. Restore VTI's original estimate or reload the page. Raise the objective to **99%**. Expect **No mix meets the objective and reserve rule**; the app must not quietly lower the target. Restore 6.5% afterward.
7. Use **Download this decision evidence** to save the actual settings, estimates and result. Keep screenshots of the base/window/one-point runs if useful for the checkout.

These are annual historical estimates, not realized strategy performance or guaranteed forward returns. The displayed sample is September 2021–September 2026;60 monthly returns from 61 prices.

## Check the charts

Scroll to **Portfolio comparison** below the tables and largest-change metric. The left chart compares current/reference weights; the right plots their annual volatility and return estimates, with a dashed objective line. Toggle the last-36-month switch to see both charts move. At the base settings the risk/return points overlap because the current mix equals the reference; changing an estimate separates them. Hover for exact values.

## Check the four-sleeve supplement

Choose **Four-sleeve practice**. This uses real historical SGOV/IEF/LQD/VTI proxies, with explicit on-page labeling. With 6.5% / 3% and no edits, expect bills/notes/IG/equity **70/0/0/30**, estimate 6.54% and volatility 4.85%. This is a separate practice example and does not impersonate the original course table.

## Meridian confirmation

I confirmed that Meridian is verified. The original course table is not bundled in this local folder, so the **Meridian training** mode transparently reports that replay is unavailable. Its missing-source notice does not erase my confirmation, and it should not be confused with the separate Four-sleeve practice outputs.

I am a student, not a financial professional. This document was prepared for FIN 43900 (AI Finance Applications, Purdue) as a class learning exercise. It is not professional investment research or financial advice. I used OpenAI Codex to help with research, analysis, calculations, and drafting. Any remaining errors are my own.
