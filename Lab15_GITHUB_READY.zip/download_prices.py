"""Download selected funds only after mandate tickers are supplied. No invented prices."""
import argparse,json,hashlib
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
import yfinance as yf
p=argparse.ArgumentParser();p.add_argument('tickers',nargs='+');p.add_argument('--end-month',default='2026-09');a=p.parse_args()
if not 3<=len(set(a.tickers))<=6:raise SystemExit('Supply 3–6 distinct actual mandate tickers.')
end=pd.Period(a.end_month,freq='M');start=end-60;series={};sources=[]
for ticker in a.tickers:
 data=yf.download(ticker,start=str(start.start_time.date()),end=str((end+1).start_time.date()),auto_adjust=False,progress=False)
 if data.empty:raise SystemExit(f'No downloaded data for {ticker}; stop.')
 col=data['Adj Close'];col=col.iloc[:,0] if isinstance(col,pd.DataFrame) else col
 monthly=col.resample('ME').last();monthly.index=monthly.index.tz_localize(None).to_period('M');monthly=monthly.reindex(pd.period_range(start,end,freq='M'))
 if monthly.isna().any() or (monthly<=0).any():raise SystemExit(f'Missing/invalid prices for {ticker}; no filling or truncation.')
 series[ticker]=monthly
 sources.append({'ticker':ticker,'source':f'https://finance.yahoo.com/quote/{ticker}/history/','field':'Adj Close','retrieved_utc':datetime.now(timezone.utc).isoformat(),'method':'daily adjusted close, last available observation per calendar month; split/dividend-adjustment provider-defined'})
frame=pd.DataFrame(series);frame.index=frame.index.to_timestamp(how='end').normalize();frame.index.name='date'
root=Path(__file__).resolve().parent;frame.to_csv(root/'prices.csv',date_format='%Y-%m-%d')
(root/'price_sources.json').write_text(json.dumps({'sources':sources,'start':str(start),'end':str(end),'price_rows':len(frame),'sha256':hashlib.sha256((root/'prices.csv').read_bytes()).hexdigest()},indent=2)+'\n')
print('Saved 61 monthly prices, 60 returns, and source metadata. Provider metadata is not point-in-time availability proof.')
